package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int postId;
	private String postContent;
	private String email;

	public Post(String postContent) {
		super();
		this.postContent = postContent;
		
	}
	public Post() {
		// TODO Auto-generated constructor stub
	}
	public Post(String postContent, String email) {
		super();
		this.postContent = postContent;
		this.email = email;
	}

	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public String getPostContent() {
		return postContent;
	}
	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}
	@Override
	public String toString() {
		return "Post [postId=" + postId + ", postContent=" + postContent + ", email=" + email + "]";
	}
	
	

}
