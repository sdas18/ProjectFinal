package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.CapBookUser;
import com.cg.capbook.beans.Post;

public interface IUserPost {
public Post savePost(String postContent , String email );
public  List<Post>getAllPost();
}
