package com.cg.capbook.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.CapBookUser;
import com.cg.capbook.beans.Post;
import com.cg.capbook.daoservices.postDAO;
@Component("userpost")
public class UserPostImpl implements IUserPost {
	@Autowired
	postDAO postdao;
	

	@Override
	public Post savePost(String postContent, String email) {
		Post post=new Post(postContent, email);
		post=postdao.save(post);
		return post;
	}

	@Override
	public List<Post> getAllPost() {
	return	postdao.findAll();
	
		
	}
	

}
